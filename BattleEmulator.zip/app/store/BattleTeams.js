Ext.define('BattleEmulator.store.BattleTeams', {
    extend: 'Ext.data.Store',

    alias: 'store.BattleTeams',

    model: 'BattleTeam',

    proxy : {
        type: 'ajax',
        url: 'http://localhost:1841/resources/testBattleTeamsData.json',
        proxy: {
            type: 'json'
        }
    }
    //data: [{name:'test', fightPower: 100, 'mons.attack': 123}]
});
