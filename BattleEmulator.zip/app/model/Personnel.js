Ext.define('BattleEmulator.model.Personnel', {
    extend: 'BattleEmulator.model.Base',

    fields: [
        'name', 'email', 'phone'
    ]
});
