Ext.define('BattleEmulator.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'BattleEmulator.model'
    }
});
