Ext.define('BattleEmulator.view.battle.EmulatorModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.battle-emulator',
    data: {
        name: 'BattleEmulator',
        selfMs:[],
        opponentMs:[]
    }

});
