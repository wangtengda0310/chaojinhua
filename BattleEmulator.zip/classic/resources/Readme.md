# classic/resources

This folder contains resources (such as images) needed by the classic build profile. 

This file can be removed.
